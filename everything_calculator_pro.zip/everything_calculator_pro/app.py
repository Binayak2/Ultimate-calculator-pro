from flask import Flask, render_template, request, jsonify
import math

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/calculate', methods=['POST'])
def calculate():
    try:
        data = request.json
        calc_type = data.get('type')
        result = None
        error = None

        if calc_type == 'basic_math':
            expression = data.get('expression')
            try:
                # WARNING: eval() can be dangerous with untrusted input.
                # For a production application, use a safer math expression parser.
                # Example: Use a library like 'sympy' or parse manually for safety.
                # For this learning example, we proceed with eval for simplicity.
                # To handle sqrt: replace sqrt(X) with math.sqrt(X)
                processed_expression = expression.replace('sqrt(', 'math.sqrt(')
                result = eval(processed_expression)
                result = f"Result: {result:.4f}"
            except (SyntaxError, ZeroDivisionError, TypeError, NameError) as e:
                error = f"Basic Math Error: {e}"
            except Exception as e:
                error = f"An unexpected basic math error occurred: {e}"

        # --- Electrical & Electrical Laws Calculation ---
        elif calc_type == 'ohms_law':
            known = data.get('known')
            val1 = float(data.get('val1'))
            val2 = float(data.get('val2'))

            if known == 'V_from_IR':
                result = val1 * val2 # V = I * R
                result = f"Voltage (V) = {result:.4f} V"
            elif known == 'I_from_VR':
                if val2 == 0: raise ZeroDivisionError("Resistance cannot be zero.")
                result = val1 / val2 # I = V / R
                result = f"Current (I) = {result:.4f} A"
            elif known == 'R_from_VI':
                if val2 == 0: raise ZeroDivisionError("Current cannot be zero.")
                result = val1 / val2 # R = V / I
                result = f"Resistance (R) = {result:.4f} Ω"
            else:
                error = "Invalid Ohm's Law selection."

        elif calc_type == 'power_law':
            known = data.get('known')
            val1 = float(data.get('val1'))
            val2 = float(data.get('val2'))

            if known == 'P_from_VI':
                result = val1 * val2 # P = V * I
                result = f"Power (P) = {result:.4f} W"
            elif known == 'P_from_IR':
                result = (val1 ** 2) * val2 # P = I^2 * R
                result = f"Power (P) = {result:.4f} W"
            elif known == 'P_from_VR':
                if val2 == 0: raise ZeroDivisionError("Resistance cannot be zero.")
                result = (val1 ** 2) / val2 # P = V^2 / R
                result = f"Power (P) = {result:.4f} W"
            else:
                error = "Invalid Power Law selection."

        elif calc_type == 'energy_charge_conductance':
            sub_type = data.get('sub_type')
            val1 = float(data.get('val1'))
            val2 = float(data.get('val2'))
            val3 = float(data.get('val3', 0)) # For capacitance in Q=CV

            if sub_type == 'energy':
                result = val1 * val2 # E = P * t
                result = f"Energy (E) = {result:.4f} J (Watt-seconds)"
            elif sub_type == 'charge_IT':
                result = val1 * val2 # Q = I * t
                result = f"Charge (Q) = {result:.4f} C (Coulombs)"
            elif sub_type == 'charge_CV':
                result = val1 * val2 # Q = C * V (val1 is C, val2 is V)
                result = f"Charge (Q) = {result:.4f} C (Coulombs)"
            elif sub_type == 'conductance':
                if val1 == 0: raise ZeroDivisionError("Resistance cannot be zero.")
                result = 1 / val1 # G = 1 / R
                result = f"Conductance (G) = {result:.4f} S (Siemens)"
            else:
                error = "Invalid Energy/Charge/Conductance selection."

        elif calc_type == 'impedance_rlc_series':
            R = float(data.get('R'))
            L = float(data.get('L'))
            C = float(data.get('C'))
            f = float(data.get('f'))

            # Ensure f is not zero for Xc calculation
            if f == 0: raise ValueError("Frequency (f) cannot be zero for AC calculations.")

            XL = 2 * math.pi * f * L
            XC = 1 / (2 * math.pi * f * C) if C != 0 else float('inf') # Handle C=0
            
            if C == 0 and L == 0:
                Z = R
            elif C == 0: # Pure RL circuit
                Z = math.sqrt(R**2 + XL**2)
            elif L == 0: # Pure RC circuit
                Z = math.sqrt(R**2 + XC**2)
            else: # RLC circuit
                Z = math.sqrt(R**2 + (XL - XC)**2)
            
            result = f"Impedance (Z) = {Z:.4f} Ω<br>Inductive Reactance (XL) = {XL:.4f} Ω<br>Capacitive Reactance (XC) = {XC:.4f} Ω"

        elif calc_type == 'power_factor_ac':
            real_power = float(data.get('real_power'))
            apparent_power = float(data.get('apparent_power'))
            
            if apparent_power == 0: raise ZeroDivisionError("Apparent Power cannot be zero.")
            
            pf = real_power / apparent_power
            result = f"Power Factor (PF) = {pf:.4f} (cosθ)"

        elif calc_type == 'rms_value':
            peak_value = float(data.get('peak_value'))
            rms = 0.707 * peak_value
            result = f"RMS Value = {rms:.4f}"

        elif calc_type == 'frequency_period':
            known = data.get('known')
            val = float(data.get('val'))

            if known == 'f_from_T':
                if val == 0: raise ZeroDivisionError("Period (T) cannot be zero.")
                result = 1 / val # f = 1 / T
                result = f"Frequency (f) = {result:.4f} Hz"
            elif known == 'T_from_f':
                if val == 0: raise ZeroDivisionError("Frequency (f) cannot be zero.")
                result = 1 / val # T = 1 / f
                result = f"Period (T) = {result:.4f} s"

        elif calc_type == 'resonant_frequency':
            L = float(data.get('L'))
            C = float(data.get('C'))
            if L <= 0 or C <= 0: raise ValueError("L and C must be positive for resonant frequency.")
            
            fr = 1 / (2 * math.pi * math.sqrt(L * C))
            result = f"Resonant Frequency (f_r) = {fr:.4f} Hz"

        elif calc_type == 'series_resistors':
            resistors_str = data.get('resistors')
            resistors = [float(r.strip()) for r in resistors_str.split(',') if r.strip()]
            if not resistors: raise ValueError("Please enter resistor values.")
            total_R = sum(resistors)
            result = f"Total Series Resistance = {total_R:.4f} Ω"

        elif calc_type == 'parallel_resistors':
            resistors_str = data.get('resistors')
            resistors = [float(r.strip()) for r in resistors_str.split(',') if r.strip()]
            if not resistors: raise ValueError("Please enter resistor values.")
            for r in resistors:
                if r == 0: raise ZeroDivisionError("Parallel resistance cannot be zero.")
            inv_sum = sum(1/r for r in resistors)
            total_R = 1 / inv_sum
            result = f"Total Parallel Resistance = {total_R:.4f} Ω"

        elif calc_type == 'rc_time_constant':
            R = float(data.get('R'))
            C = float(data.get('C'))
            if R < 0 or C < 0: raise ValueError("Resistance and Capacitance cannot be negative.")
            tau = R * C
            result = f"RC Time Constant (τ) = {tau:.6f} seconds" # often small values

        elif calc_type == 'battery_life':
            capacity_mah = float(data.get('capacity_mah'))
            load_current_ma = float(data.get('load_current_ma'))
            if load_current_ma <= 0: raise ValueError("Load current must be positive.")
            life_hours = capacity_mah / load_current_ma
            result = f"Battery Life = {life_hours:.2f} hours"

        # --- Finance Related Calculation ---
        elif calc_type == 'simple_interest':
            principal = float(data.get('principal'))
            rate = float(data.get('rate')) / 100 # Convert percentage to decimal
            time = float(data.get('time'))

            if principal < 0 or rate < 0 or time < 0:
                raise ValueError("Principal, Rate, and Time cannot be negative for simple interest.")

            interest = principal * rate * time
            total_amount = principal + interest
            result = f"Interest: {interest:.2f}, Total Amount: {total_amount:.2f}"

        # --- Placeholder for 'etc.' ---
        elif calc_type == 'custom_hypotenuse':
            side_a = float(data.get('side_a'))
            side_b = float(data.get('side_b'))
            if side_a < 0 or side_b < 0:
                raise ValueError("Sides of a triangle cannot be negative.")
            hypotenuse = math.sqrt(side_a**2 + side_b**2)
            result = f"Hypotenuse: {hypotenuse:.4f}"

        else:
            error = "Unknown calculation type."

    except ValueError as e:
        error = f"Input Error: {e}. Please ensure all inputs are valid numbers."
    except ZeroDivisionError as e:
        error = f"Calculation Error: {e}. Division by zero or invalid operation."
    except Exception as e:
        error = f"An unexpected server error occurred: {e}"

    return jsonify({'result': result, 'error': error})

if __name__ == '__main__':
    # For development, use debug=True. In production, use a WSGI server (e.g., Gunicorn).
    app.run(debug=True, host='0.0.0.0') # Listen on all interfaces