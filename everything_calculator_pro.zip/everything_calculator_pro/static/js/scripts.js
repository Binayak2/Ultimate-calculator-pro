// Function to handle tab switching
function openTab(evt, tabName) {
    var i, tabcontent, tabbuttons;

    tabcontent = document.getElementsByClassName("tab-content");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].classList.remove("active");
    }

    tabbuttons = document.getElementsByClassName("tab-button");
    for (i = 0; i < tabbuttons.length; i++) {
        tabbuttons[i].classList.remove("active");
    }

    document.getElementById(tabName).classList.add("active");
    evt.currentTarget.classList.add("active");

    // Optional: Update initial values for specific tabs if needed
    if (tabName === 'electricalDC') {
        updateOhmInputs();
        updatePowerInputs();
        updateEqgInputs();
    }
}

// Helper function to send data to the backend
async function sendCalculation(data, resultId, errorId) {
    const resultElement = document.getElementById(resultId);
    const errorElement = document.getElementById(errorId);

    resultElement.style.display = 'none';
    errorElement.style.display = 'none';
    resultElement.innerHTML = ''; // Clear previous content
    errorElement.innerHTML = ''; // Clear previous content

    try {
        const response = await fetch('/calculate', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });

        const responseData = await response.json();

        if (responseData.error) {
            errorElement.innerHTML = responseData.error;
            errorElement.style.display = 'block';
        } else {
            resultElement.innerHTML = responseData.result;
            resultElement.style.display = 'block';
        }
    } catch (e) {
        errorElement.innerHTML = `Network error: ${e.message}. Please check server connection.`;
        errorElement.style.display = 'block';
    }
}

// --- Calculation Functions ---

function calculateBasic() {
    const expression = document.getElementById('basicExpression').value;
    sendCalculation({ type: 'basic_math', expression: expression }, 'basicResult', 'basicError');
}

// --- DC Circuit Functions ---
function updateOhmInputs() {
    const known = document.getElementById('ohmsKnown').value;
    document.getElementById('ohmsVal1').value = ''; // Clear values on change
    document.getElementById('ohmsVal2').value = '';

    if (known === 'V_from_IR') {
        document.getElementById('ohmsVal1Label').textContent = 'Current (I) [Amps]:';
        document.getElementById('ohmsVal2Label').textContent = 'Resistance (R) [Ohms]:';
    } else if (known === 'I_from_VR') {
        document.getElementById('ohmsVal1Label').textContent = 'Voltage (V) [Volts]:';
        document.getElementById('ohmsVal2Label').textContent = 'Resistance (R) [Ohms]:';
    } else if (known === 'R_from_VI') {
        document.getElementById('ohmsVal1Label').textContent = 'Voltage (V) [Volts]:';
        document.getElementById('ohmsVal2Label').textContent = 'Current (I) [Amps]:';
    }
}

function calculateOhm() {
    const known = document.getElementById('ohmsKnown').value;
    const val1 = document.getElementById('ohmsVal1').value;
    const val2 = document.getElementById('ohmsVal2').value;
    sendCalculation({ type: 'ohms_law', known: known, val1: val1, val2: val2 }, 'ohmsResult', 'ohmsError');
}

function updatePowerInputs() {
    const known = document.getElementById('powerKnown').value;
    document.getElementById('powerVal1').value = ''; // Clear values on change
    document.getElementById('powerVal2').value = '';

    if (known === 'P_from_VI') {
        document.getElementById('powerVal1Label').textContent = 'Voltage (V) [Volts]:';
        document.getElementById('powerVal2Label').textContent = 'Current (I) [Amps]:';
    } else if (known === 'P_from_IR') {
        document.getElementById('powerVal1Label').textContent = 'Current (I) [Amps]:';
        document.getElementById('powerVal2Label').textContent = 'Resistance (R) [Ohms]:';
    } else if (known === 'P_from_VR') {
        document.getElementById('powerVal1Label').textContent = 'Voltage (V) [Volts]:';
        document.getElementById('powerVal2Label').textContent = 'Resistance (R) [Ohms]:';
    }
}

function calculatePower() {
    const known = document.getElementById('powerKnown').value;
    const val1 = document.getElementById('powerVal1').value;
    const val2 = document.getElementById('powerVal2').value;
    sendCalculation({ type: 'power_law', known: known, val1: val1, val2: val2 }, 'powerResult', 'powerError');
}

function updateEqgInputs() {
    const sub_type = document.getElementById('e_q_g_type').value;
    document.getElementById('eqgVal1').value = ''; // Clear values on change
    document.getElementById('eqgVal2').value = '';

    const label1 = document.getElementById('eqgVal1Label');
    const label2 = document.getElementById('eqgVal2Label');

    if (sub_type === 'energy') {
        label1.textContent = 'Power (P) [Watts]:';
        label2.textContent = 'Time (t) [Seconds]:';
    } else if (sub_type === 'charge_IT') {
        label1.textContent = 'Current (I) [Amps]:';
        label2.textContent = 'Time (t) [Seconds]:';
    } else if (sub_type === 'charge_CV') {
        label1.textContent = 'Capacitance (C) [Farads]:';
        label2.textContent = 'Voltage (V) [Volts]:';
    } else if (sub_type === 'conductance') {
        label1.textContent = 'Resistance (R) [Ohms]:';
        label2.textContent = ''; // Only one input needed
        document.getElementById('eqgVal2').style.display = 'none'; // Hide second input
        return; // Exit to avoid showing it later
    }
    document.getElementById('eqgVal2').style.display = 'block'; // Ensure it's visible for other types
}

function calculateEqg() {
    const sub_type = document.getElementById('e_q_g_type').value;
    const val1 = document.getElementById('eqgVal1').value;
    const val2 = document.getElementById('eqgVal2').value; // Might be empty for conductance

    const data = { type: 'energy_charge_conductance', sub_type: sub_type, val1: val1 };
    if (sub_type !== 'conductance') { // Only add val2 if needed
        data.val2 = val2;
    }
    sendCalculation(data, 'eqgResult', 'eqgError');
}

// --- AC Circuit Functions ---
function calculateImpedance() {
    const R = document.getElementById('impedanceR').value;
    const L = document.getElementById('impedanceL').value;
    const C = document.getElementById('impedanceC').value;
    const f = document.getElementById('impedanceF').value;
    sendCalculation({ type: 'impedance_rlc_series', R: R, L: L, C: C, f: f }, 'impedanceResult', 'impedanceError');
}

function calculatePowerFactor() {
    const real_power = document.getElementById('realPower').value;
    const apparent_power = document.getElementById('apparentPower').value;
    sendCalculation({ type: 'power_factor_ac', real_power: real_power, apparent_power: apparent_power }, 'powerFactorResult', 'powerFactorError');
}

function calculateRMS() {
    const peak_value = document.getElementById('peakValue').value;
    sendCalculation({ type: 'rms_value', peak_value: peak_value }, 'rmsResult', 'rmsError');
}

function calculateFreqPeriod() {
    const known = document.getElementById('freqPeriodKnown').value;
    const val = document.getElementById('freqPeriodValue').value;
    sendCalculation({ type: 'frequency_period', known: known, val: val }, 'freqPeriodResult', 'freqPeriodError');
}

function calculateResonantFreq() {
    const L = document.getElementById('resFreqL').value;
    const C = document.getElementById('resFreqC').value;
    sendCalculation({ type: 'resonant_frequency', L: L, C: C }, 'resFreqResult', 'resFreqError');
}

// --- Circuit Analysis Functions ---
function calculateResistorComb() {
    const type = document.getElementById('resistorType').value;
    const resistors = document.getElementById('resistorValues').value;
    sendCalculation({ type: `${type}_resistors`, resistors: resistors }, 'resistorCombResult', 'resistorCombError');
}

function calculateRCTimeConstant() {
    const R = document.getElementById('rcR').value;
    const C = document.getElementById('rcC').value;
    sendCalculation({ type: 'rc_time_constant', R: R, C: C }, 'rcTimeResult', 'rcTimeError');
}

// --- Electronics Specific Functions ---
function calculateBatteryLife() {
    const capacity_mah = document.getElementById('batteryCapacity').value;
    const load_current_ma = document.getElementById('loadCurrent').value;
    sendCalculation({ type: 'battery_life', capacity_mah: capacity_mah, load_current_ma: load_current_ma }, 'batteryLifeResult', 'batteryLifeError');
}


// --- Finance Functions ---
function calculateSimpleInterest() {
    const principal = document.getElementById('principal').value;
    const rate = document.getElementById('rate').value;
    const time = document.getElementById('time').value;
    sendCalculation({ type: 'simple_interest', principal: principal, rate: rate, time: time }, 'interestResult', 'interestError');
}

// --- Etc. Functions ---
function calculateHypotenuse() {
    const side_a = document.getElementById('sideA').value;
    const side_b = document.getElementById('sideB').value;
    sendCalculation({ type: 'custom_hypotenuse', side_a: side_a, side_b: side_b }, 'hypotenuseResult', 'hypotenuseError');
}


// Initialize the first tab as active when the page loads
document.addEventListener('DOMContentLoaded', () => {
    document.querySelector('.tab-button').click(); // Clicks the first button
    updateOhmInputs(); // Initialize Ohm's Law labels
    updatePowerInputs(); // Initialize Power Law labels
    updateEqgInputs(); // Initialize E,Q,G labels
});